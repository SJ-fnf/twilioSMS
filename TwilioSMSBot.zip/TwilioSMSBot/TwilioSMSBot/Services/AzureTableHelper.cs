﻿using Azure;
using Azure.Data.Tables;
using Azure.Data.Tables.Models;
using Azure.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Rest;
using System;
using System.Linq;
using System.Threading.Tasks;
using TwilioSMSBot.Core;

namespace TwilioSMSBot.Services
{
    public class AzureTableHelper
    {
        private TableServiceClient _tableServiceClient;
        private string tableName = "UserIDTokenMapping";
        private readonly TableClient _userIDMappingTable;
        public AzureTableHelper(IConfiguration configuration)
        {
            var credential = new DefaultAzureCredential();
            _tableServiceClient = new TableServiceClient(new Uri("https://advchatbotstorageaccount.table.core.windows.net/"), credential);
            _userIDMappingTable = _tableServiceClient.GetTableClient(tableName);
            //_userIDMappingTable.CreateIfNotExists();
        }

        public async Task<bool> insertUserIDTokenMappingAsync(string userId,string Token)
        {
            try
            {
                UserIDMappingEntity entity = new() { PartitionKey="Prod", RowKey=userId,Token = Token,UserID = userId };
                await _userIDMappingTable.UpsertEntityAsync(entity);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public string GetTokenIfExists(string userID)
        {
            try
            {
                Pageable<UserIDMappingEntity> queryResultsFilter = _userIDMappingTable.Query<UserIDMappingEntity>(filter: $"UserID eq '{userID}'");
                return queryResultsFilter?.FirstOrDefault()?.Token ?? null;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
