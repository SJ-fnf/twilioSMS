﻿using Microsoft.AspNetCore.Mvc;
namespace TwilioSMSBot.Controllers
{
    public class ChatbotController : Controller
    {
        public IActionResult Index(string token)
        {
            if (token == null)
                return BadRequest("Invalid token");
            ViewBag.Token = token;
            return View();
        }
    }
}
