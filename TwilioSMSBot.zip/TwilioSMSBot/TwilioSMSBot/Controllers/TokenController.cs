﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TwilioSMSBot.Services;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;
//using System.Web.Http.Cors;
using Microsoft.Bot.Builder;
using System.Net.Http;
using Microsoft.AspNetCore.Cors;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;

namespace TwilioSMSBot.Controllers
{
    //[EnableCors(origins: "*", headers: "*", methods: "*")]
    [Route("api/[controller]")]
    [ApiController]
    public class TokenController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly AzureTableHelper _azureTableHelper;
        private readonly IBotTelemetryClient _telemetryClient;
        private readonly IHttpClientFactory _httpClientFactory;
        public TokenController(IConfiguration configuration, AzureTableHelper azureTableHelper, IServiceProvider services, IHttpClientFactory httpClientFactory)
        {
            _configuration = configuration;
            _azureTableHelper = azureTableHelper;
            _telemetryClient = (IBotTelemetryClient)services.GetService(typeof(IBotTelemetryClient));
            _httpClientFactory = httpClientFactory; //Inject IHttpClientFactory
        }
        // GET api/<ValuesController>/5
        [Microsoft.AspNetCore.Mvc.HttpGet("fetch")]
        public async Task<DirectLineToken> GetAsync(string id, string userName)
        {
            DirectLineToken body = new DirectLineToken();
            string domain = string.IsNullOrEmpty(Request.Headers["Origin"].ToString()) ? Request.Headers["Host"].ToString() : Request.Headers["Origin"].ToString();
            this.Response.Headers.Add("Content-Type", "application/json");
            if (domain.ToLower().EndsWith("fnf.com") || !string.IsNullOrEmpty(userName))
            {
                id = System.Uri.UnescapeDataString(id);
                string token = String.Empty;

                if (string.IsNullOrEmpty(token))
                {

                    var secret = "o11rqN8l3hQ.ZUkH3N-blX16F9GY526U3glRNYPddLHNFEryLdRzzIQ";//_configuration["BotSecret"];
                    HttpClient client = new HttpClient();
                    HttpRequestMessage request = new HttpRequestMessage(
                      HttpMethod.Post,
                      $"https://directline.botframework.com/v3/directline/tokens/generate");
                    request.Headers.Add("Authorization", $"Bearer {secret}");
                    request.Content = new StringContent(
                    JsonConvert.SerializeObject(
                        new { User = new { Id = (userName ?? "Test User").Replace(" ", "") } }),
                        Encoding.UTF8,
                        "application/json");
                    var response = await client.SendAsync(request);
                    if (response.IsSuccessStatusCode)
                    {
                        body = JsonConvert.DeserializeObject<DirectLineToken>(await response.Content.ReadAsStringAsync());
                        //await saveUserIDTokenAsync(body.conversationId, body.token);
                    }
                }
                else
                    body.token = token;
                return body;
            }
            else
            {
                body.token = "Unauthorised Access - " + domain;
                return body;
            }
        }

        [Microsoft.AspNetCore.Mvc.HttpGet("trackbc")]
        public async Task<bool> CaptureButtonClick(string Id, string action)
        {
            Dictionary<string, string> logs = new();
            string convId = System.Uri.UnescapeDataString(Id);

            try
            {
                string domain = string.IsNullOrEmpty(Request.Headers["Origin"].ToString()) ? Request.Headers["Host"].ToString() : Request.Headers["Origin"].ToString();
                if (domain.ToLower().EndsWith("fnf.com"))
                {
                    logs.TryAdd("ConversationID", $"{convId}");
                    logs.TryAdd("Question", $"User Clicked and {action} bot icon");
                    logs.TryAdd("Response", $"User Clicked and {action} bot icon");
                    logs.TryAdd("Channel", $"directline");
                    _telemetryClient.TrackEvent("Conversations", logs);
                    return true;
                }
                else
                    return true;
            }
            catch (Exception ex)
            {
                logs.TryAdd("ConversationID", $"{convId}");
                logs.TryAdd("Question", $"User Clicked and {action} bot icon");
                logs.TryAdd("StackTrace", ex.StackTrace ?? "");
                logs.TryAdd("Channel", $"directline");
                _telemetryClient.TrackEvent("Exception", logs);
                return false;
            }
        }
        public class DirectLineToken
        {
            public string conversationId { get; set; }
            public string token { get; set; }
            public int expires_in { get; set; }
        }

        private async Task saveUserIDTokenAsync(string id, string token)
        {
            await _azureTableHelper.insertUserIDTokenMappingAsync(id, token);
        }
    }
}
