﻿//using Microsoft.AspNetCore.Http;
//using Microsoft.Bot.Builder;
//using Microsoft.Bot.Schema;
//using Microsoft.Extensions.Configuration;
//using System;
//using System.Collections.Generic;
//using System.Threading;
//using System.Threading.Tasks;
//using Twilio;
//using Twilio.Base;
//using Twilio.TwiML;
//using Twilio.TwiML.Messaging;
//using Twilio.Rest.Api.V2010.Account;

//namespace TwilioSMSBot.Adapters
//{
//    public class TwilioAdapter : BotAdapter
//    {
//        private readonly string _accountSid;
//        private readonly string _authToken;
//        private readonly string _phoneNumber;

//        public TwilioAdapter(IConfiguration configuration)
//        {
//            // Read Twilio credentials from configuration
//            _accountSid = configuration["Twilio:AccountSID"];
//            _authToken = configuration["Twilio:AuthToken"];
//            _phoneNumber = configuration["Twilio:PhoneNumber"];

//            // Initialize Twilio client with credentials
//            TwilioClient.Init(_accountSid, _authToken);
//        }

//        //public async Task ProcessAsync(HttpRequest httpRequest, HttpResponse httpResponse, IBot bot)
//        //{
//        //    //// Extract the incoming Twilio message from the request
//        //    //var formCollection = await httpRequest.ReadFormAsync();
//        //    //var fromNumber = formCollection["From"];
//        //    //var body = formCollection["Body"];

//        //    //// Create an activity based on the Twilio message
//        //    //var activity = new Activity
//        //    //{
//        //    //    Type = ActivityTypes.Message,
//        //    //    Text = body,
//        //    //    From = new ChannelAccount(fromNumber),
//        //    //    Recipient = new ChannelAccount("Bot"),
//        //    //    Conversation = new ConversationAccount(id: fromNumber)
//        //    //};

//        //    //// Create a turn context and run the bot logic
//        //    //var turnContext = new TurnContext(this, activity);
//        //    //await bot.OnTurnAsync(turnContext, CancellationToken.None);

//        //    //// Send response back to Twilio
//        //    //// Send response back to Twilio
//        //    //await SendActivitiesAsync(turnContext, new List<Activity> { activity }.ToArray(), CancellationToken.None);


//        //    //// Set response type
//        //    //httpResponse.ContentType = "text/xml";
//        //    //await httpResponse.WriteAsync("<Response></Response>");
//        //    var message = new MessagingResponse();
//        //    message.Message("Bot received your message!");

//        //    httpResponse.ContentType = "text/xml";
//        //    await httpResponse.WriteAsync(message.ToString());
//        //}

//        public async Task ProcessAsync(HttpRequest httpRequest, HttpResponse httpResponse, IBot bot)
//        {
//            // Process the incoming message
//            await base.ProcessAsync(httpRequest, httpResponse, bot);

//            // Ensure a 200 OK status is sent back to Twilio
//            httpResponse.StatusCode = StatusCodes.Status200OK;
//        }

//        public override async Task<ResourceResponse[]> SendActivitiesAsync(ITurnContext turnContext, Activity[] activities, CancellationToken cancellationToken)
//        {
//            var responses = new List<ResourceResponse>();

//            foreach (var activity in activities)
//            {
//                if (activity.Type == ActivityTypes.Message)
//                {
//                    var message = activity.Text;

//                    // Send the message to Twilio
//                    var twilioMessage = await MessageResource.CreateAsync(
//                        body: message,
//                        from: new Twilio.Types.PhoneNumber(_phoneNumber),
//                        to: new Twilio.Types.PhoneNumber(turnContext.Activity.From.Id)
//                    );

//                    responses.Add(new ResourceResponse(twilioMessage.Sid));
//                }
//            }

//            // Ensure HTTP response is 200 OK
//            turnContext.TurnState.Get<HttpResponse>().StatusCode = StatusCodes.Status200OK;

//            return responses.ToArray();
//        }


//        //public override async Task<ResourceResponse[]> SendActivitiesAsync(ITurnContext turnContext, Activity[] activities, CancellationToken cancellationToken)
//        //{
//        //    var responses = new List<ResourceResponse>();

//        //    foreach (var activity in activities)
//        //    {
//        //        if (activity.Type == ActivityTypes.Message)
//        //        {
//        //            var message = new MessagingResponse();
//        //            message.Message(activity.Text);

//        //            var response = turnContext.TurnState.Get<HttpResponse>();
//        //            response.ContentType = "text/xml";
//        //            await response.WriteAsync(message.ToString());

//        //            responses.Add(new ResourceResponse(activity.Id));
//        //        }
//        //    }

//        //    return responses.ToArray();
//        //}

//        public override Task DeleteActivityAsync(ITurnContext turnContext, ConversationReference reference, CancellationToken cancellationToken)
//        {
//            throw new NotImplementedException();
//        }

//        public override Task<ResourceResponse> UpdateActivityAsync(ITurnContext turnContext, Activity activity, CancellationToken cancellationToken)
//        {
//            throw new NotImplementedException();
//        }
//    }
//}


using Microsoft.AspNetCore.Http;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Configuration;

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;  // Added this line
using Twilio.Types;
using Twilio.TwiML;
using Twilio.TwiML.Messaging;

namespace TwilioSMSBot.Adapters
{
    public class TwilioAdapter : BotAdapter
    {
        private readonly string _accountSid;
        private readonly string _authToken;
        private readonly string _phoneNumber;

        public TwilioAdapter(IConfiguration configuration)
        {
            _accountSid = configuration["Twilio:AccountSID"];
            _authToken = configuration["Twilio:AuthToken"];
            _phoneNumber = configuration["Twilio:PhoneNumber"];

            TwilioClient.Init(_accountSid, _authToken);
        }

        public async Task ProcessAsync(HttpRequest httpRequest, HttpResponse httpResponse, IBot bot)
        {
            try
            {
                var formCollection = await httpRequest.ReadFormAsync();
                var fromNumber = formCollection["From"];
                var body = formCollection["Body"];

                var activity = new Activity
                {
                    Type = ActivityTypes.Message,
                    Text = body,
                    From = new ChannelAccount(fromNumber),
                    Recipient = new ChannelAccount("Bot"),
                    Conversation = new ConversationAccount(id: fromNumber)
                };

                var turnContext = new TurnContext(this, activity);
                await bot.OnTurnAsync(turnContext, CancellationToken.None);

                // Ensure a 200 OK status only once here
                httpResponse.StatusCode = StatusCodes.Status200OK;
                httpResponse.ContentType = "text/xml";
                await httpResponse.WriteAsync("<Response></Response>");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing Twilio webhook: {ex.Message}");
                httpResponse.StatusCode = StatusCodes.Status500InternalServerError;
            }
        }

        public override async Task<ResourceResponse[]> SendActivitiesAsync(ITurnContext turnContext, Activity[] activities, CancellationToken cancellationToken)
        {
            var responses = new List<ResourceResponse>();

            foreach (var activity in activities)
            {
                if (activity.Type == ActivityTypes.Message)
                {
                    var message = activity.Text;

                    var twilioMessage = await MessageResource.CreateAsync(
                        body: message,
                        from: new PhoneNumber(_phoneNumber),
                        to: new PhoneNumber(turnContext.Activity.From.Id)
                    );

                    responses.Add(new ResourceResponse(twilioMessage.Sid));
                }
            }

            // Do not set the response status code here to avoid duplication
            return responses.ToArray();
        }

        //public async Task ProcessAsync(HttpRequest httpRequest, HttpResponse httpResponse, IBot bot)
        //{
        //    try
        //    {
        //        var formCollection = await httpRequest.ReadFormAsync();
        //        var fromNumber = formCollection["From"];
        //        var body = formCollection["Body"];

        //        var activity = new Activity
        //        {
        //            Type = ActivityTypes.Message,
        //            Text = body,
        //            From = new ChannelAccount(fromNumber),
        //            Recipient = new ChannelAccount("Bot"),
        //            Conversation = new ConversationAccount(id: fromNumber)
        //        };

        //        var turnContext = new TurnContext(this, activity);
        //        await bot.OnTurnAsync(turnContext, CancellationToken.None);

        //        // Ensure 200 OK status
        //        httpResponse.StatusCode = StatusCodes.Status200OK;
        //        await httpResponse.WriteAsync("<Response></Response>");  // This ensures a valid Twilio response format
        //    }
        //    catch (Exception ex)
        //    {
        //        // Log the exception
        //        Console.WriteLine($"Error processing Twilio webhook: {ex.Message}");
        //        httpResponse.StatusCode = StatusCodes.Status500InternalServerError;
        //    }
        //}



        //public override async Task<ResourceResponse[]> SendActivitiesAsync(ITurnContext turnContext, Activity[] activities, CancellationToken cancellationToken)
        //{
        //    var responses = new List<ResourceResponse>();

        //    foreach (var activity in activities)
        //    {
        //        if (activity.Type == ActivityTypes.Message)
        //        {
        //            var message = activity.Text;

        //            var twilioMessage = await MessageResource.CreateAsync(
        //                body: message,
        //                from: new PhoneNumber(_phoneNumber),
        //                to: new PhoneNumber(turnContext.Activity.From.Id)
        //            );

        //            responses.Add(new ResourceResponse(twilioMessage.Sid));
        //        }
        //    }

        //    turnContext.TurnState.Get<HttpResponse>().StatusCode = StatusCodes.Status200OK;

        //    return responses.ToArray();
        //}

        public override Task DeleteActivityAsync(ITurnContext turnContext, ConversationReference reference, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public override Task<ResourceResponse> UpdateActivityAsync(ITurnContext turnContext, Activity activity, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }
}

